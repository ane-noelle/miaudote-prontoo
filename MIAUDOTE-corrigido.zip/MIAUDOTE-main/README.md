# MIAUDOTE

Plataforma web para divulgação de cães e gatos para adoção (TCC).
ASP.NET Core MVC (.NET 10) + Entity Framework Core + MySQL/MariaDB.

> A pasta `SiteAntigo/` guarda o protótipo estático em HTML. O projeto real é `Miaudote.Web/`.

## Como rodar

1. **Banco de dados:** tenha um MySQL/MariaDB rodando.
2. **Conexão:** o padrão está em `Miaudote.Web/appsettings.json`
   (`localhost:3306`, usuário `root`, sem senha, banco `miaudote`).
   Para usar outra senha/servidor, crie `Miaudote.Web/appsettings.Development.json`
   (ignorado pelo git):

   ```json
   {
     "ConnectionStrings": {
       "ConexaoPadrao": "Server=localhost;Port=3306;Database=miaudote;User=root;Password=SUA_SENHA;"
     }
   }
   ```
3. **Executar:**

   ```bash
   cd Miaudote.Web
   dotnet run
   ```

   Na primeira execução as tabelas e os dados de exemplo são criados automaticamente
   (`Banco:MigrarAoIniciar` em `appsettings.json`). Se preferir controlar manualmente,
   coloque `false` e use `dotnet ef database update`.

## Área administrativa

- Endereço: `/Login` (link "Área administrativa" no rodapé do site).
- Credenciais padrão (desenvolvimento): `admin@miaudote.com.br` / `123456`.
- **Troque antes de publicar.** Elas vêm da configuração (`Administrador:Email` e
  `Administrador:Senha`) e podem ser definidas no `appsettings.Development.json`,
  em variáveis de ambiente (`Administrador__Senha`) ou em `dotnet user-secrets`.

| Menu | O que faz |
|------|-----------|
| **Painel** | Contadores em tempo real e atalhos para o que precisa de atenção |
| **Animais** | Lista com busca/filtros, cadastro e edição completos (foto, temperamentos, todos os campos), desativar/reativar |
| **Solicitações** | Fluxo Pendente → Em análise → Aprovada → Concluída (ou Recusada), com observação interna |
| **Mensagens** | Mensagens do formulário de contato: responder por e-mail, marcar como respondida, excluir |
| **Cadastros** | Espécies, cidades e temperamentos que alimentam formulários e filtros |

### Como o fluxo de adoção atualiza o animal
- **Aprovar** → animal fica "Em processo de adoção" e sai da lista pública.
- **Concluir adoção** → animal vira "Adotado", as outras solicitações abertas dele são recusadas
  e o contador "Adoções realizadas" da Home sobe.
- **Recusar/voltar para análise** uma solicitação aprovada → o animal volta a "Disponível".

## Estrutura

```
Miaudote.Web/
  Controllers/    Home, Animais, Adocao, Contato, Login, Administrador, Cadastros, Institucional
  Filters/        AdminAutorizado (protege as páginas administrativas)
  Helpers/        Formatadores (idade, rótulos), Opcoes (selects), FluxoSolicitacao
  ViewModels/     Modelos das telas
  ViewComponents/ Menu administrativo com contadores
  Views/          Telas Razor (Shared/_Layout e Shared/_AdminLayout)
  wwwroot/        css/miaudote.css, js/miaudote.js, imagens/
```

Veja `CORRECOES.md` para a lista do que foi corrigido e melhorado.
