using System.ComponentModel.DataAnnotations;
using Miaudote.Web.Models;

namespace Miaudote.Web.ViewModels;

public class SolicitarAdocaoViewModel
{
    /// <summary>Animal exibido no topo do formulário (somente leitura).</summary>
    public Animal? Animal { get; set; }

    public int AnimalId { get; set; }

    [Required(ErrorMessage = "O nome completo é obrigatório.")]
    [StringLength(150, MinimumLength = 3,
        ErrorMessage = "O nome deve possuir entre 3 e 150 caracteres.")]
    [Display(Name = "Nome completo")]
    public string NomeCompleto { get; set; } = string.Empty;

    [Required(ErrorMessage = "O e-mail é obrigatório.")]
    [EmailAddress(ErrorMessage = "Informe um e-mail válido.")]
    [StringLength(254, ErrorMessage = "O e-mail deve possuir no máximo 254 caracteres.")]
    [Display(Name = "E-mail")]
    public string Email { get; set; } = string.Empty;

    [Required(ErrorMessage = "O telefone é obrigatório.")]
    [Phone(ErrorMessage = "Informe um telefone válido.")]
    [StringLength(20, MinimumLength = 8,
        ErrorMessage = "O telefone deve possuir entre 8 e 20 caracteres.")]
    [Display(Name = "Telefone")]
    public string Telefone { get; set; } = string.Empty;

    [Required(ErrorMessage = "A cidade é obrigatória.")]
    [StringLength(100, MinimumLength = 2,
        ErrorMessage = "A cidade deve possuir entre 2 e 100 caracteres.")]
    [Display(Name = "Cidade")]
    public string Cidade { get; set; } = string.Empty;

    [Required(ErrorMessage = "O endereço é obrigatório.")]
    [StringLength(255, MinimumLength = 5,
        ErrorMessage = "O endereço deve possuir entre 5 e 255 caracteres.")]
    [Display(Name = "Endereço")]
    public string Endereco { get; set; } = string.Empty;

    [Required(ErrorMessage = "Explique o motivo da adoção.")]
    [StringLength(3000, MinimumLength = 20,
        ErrorMessage = "O motivo deve possuir entre 20 e 3000 caracteres.")]
    [Display(Name = "Motivo da adoção")]
    public string MotivoAdocao { get; set; } = string.Empty;
}
