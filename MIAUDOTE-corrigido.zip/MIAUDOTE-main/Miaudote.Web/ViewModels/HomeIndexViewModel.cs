using Miaudote.Web.Models;

namespace Miaudote.Web.ViewModels;

public class HomeIndexViewModel
{
    /// <summary>Animais mais recentes disponíveis para adoção.</summary>
    public List<Animal> Destaques { get; set; } = new();

    public int QuantidadeAnimaisDisponiveis { get; set; }

    public int QuantidadeAdocoesConcluidas { get; set; }

    public List<Cidade> Cidades { get; set; } = new();

    public List<Especie> Especies { get; set; } = new();

    public FiltroAnimaisViewModel Filtro => new()
    {
        Cidades = Cidades,
        Especies = Especies
    };
}
