using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.Rendering;
using Miaudote.Web.Enums;
using Miaudote.Web.Models;

namespace Miaudote.Web.ViewModels;

/// <summary>
/// Formulário de cadastro/edição de animal. Evita o "over-posting" que
/// existia ao receber a entidade Animal diretamente e concentra as listas
/// carregadas do banco (espécies, cidades, temperamentos).
/// </summary>
public class AnimalFormViewModel
{
    public int Id { get; set; }

    [Required(ErrorMessage = "O nome do animal é obrigatório.")]
    [StringLength(100, ErrorMessage = "O nome deve possuir no máximo 100 caracteres.")]
    [Display(Name = "Nome")]
    public string Nome { get; set; } = string.Empty;

    [Required(ErrorMessage = "Selecione a espécie.")]
    [Display(Name = "Espécie")]
    public int? EspecieId { get; set; }

    [Required(ErrorMessage = "Selecione a cidade.")]
    [Display(Name = "Cidade")]
    public int? CidadeId { get; set; }

    [StringLength(100, ErrorMessage = "A raça deve possuir no máximo 100 caracteres.")]
    [Display(Name = "Raça")]
    public string? Raca { get; set; }

    [Range(0, 30, ErrorMessage = "Informe de 0 a 30 anos.")]
    [Display(Name = "Anos")]
    public int Anos { get; set; }

    [Range(0, 11, ErrorMessage = "Informe de 0 a 11 meses.")]
    [Display(Name = "Meses")]
    public int Meses { get; set; }

    [Required(ErrorMessage = "Selecione o porte.")]
    [Display(Name = "Porte")]
    public PorteAnimal? Porte { get; set; }

    [Required(ErrorMessage = "Selecione o gênero.")]
    [Display(Name = "Gênero")]
    public GeneroAnimal? Genero { get; set; }

    [Required(ErrorMessage = "Selecione o status.")]
    [Display(Name = "Status")]
    public StatusAnimal? Status { get; set; } = StatusAnimal.Disponivel;

    [Required(ErrorMessage = "A descrição do animal é obrigatória.")]
    [StringLength(3000, MinimumLength = 10,
        ErrorMessage = "A descrição deve possuir entre 10 e 3000 caracteres.")]
    [Display(Name = "Descrição")]
    public string Descricao { get; set; } = string.Empty;

    [Display(Name = "Vacinado")]
    public bool Vacinado { get; set; }

    [Display(Name = "Castrado")]
    public bool Castrado { get; set; }

    /// <summary>Temperamentos marcados nas caixas de seleção.</summary>
    public List<int> TemperamentoIds { get; set; } = new();

    /// <summary>Foto já gravada (edição). O upload novo vem em outro parâmetro.</summary>
    public string? NomeArquivoImagem { get; set; }

    public bool Ativo { get; set; } = true;

    // ---- Listas para os selects (preenchidas pelo controller) ----
    public List<SelectListItem> Especies { get; set; } = new();
    public List<SelectListItem> Cidades { get; set; } = new();
    public List<SelectListItem> Portes { get; set; } = new();
    public List<SelectListItem> Generos { get; set; } = new();
    public List<SelectListItem> StatusOpcoes { get; set; } = new();
    public List<Temperamento> TemperamentosDisponiveis { get; set; } = new();

    public bool Edicao => Id > 0;

    public int IdadeTotalMeses => (Anos * 12) + Meses;
}
