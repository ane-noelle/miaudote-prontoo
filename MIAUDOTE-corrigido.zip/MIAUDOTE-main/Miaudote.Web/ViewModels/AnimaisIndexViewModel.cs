using Miaudote.Web.Enums;
using Miaudote.Web.Models;

namespace Miaudote.Web.ViewModels;

public class AnimaisIndexViewModel
{
    public List<Animal> Animais { get; set; } = new();

    public List<Cidade> Cidades { get; set; } = new();
    public List<Especie> Especies { get; set; } = new();

    // Filtros escolhidos pela pessoa (vêm da query string)
    public int? CidadeId { get; set; }
    public int? EspecieId { get; set; }
    public PorteAnimal? Porte { get; set; }
    public string? Busca { get; set; }

    public int Total { get; set; }
    public PaginacaoViewModel Paginacao { get; set; } = new();

    public FiltroAnimaisViewModel Filtro => new()
    {
        Cidades = Cidades,
        Especies = Especies,
        CidadeId = CidadeId,
        EspecieId = EspecieId,
        Porte = Porte,
        Busca = Busca
    };

    public bool TemFiltro => Filtro.TemFiltro;
}
