using Miaudote.Web.Enums;
using Miaudote.Web.Models;

namespace Miaudote.Web.ViewModels;

/// <summary>Dados da barra de filtros, compartilhada entre a Home e a lista de animais.</summary>
public class FiltroAnimaisViewModel
{
    public List<Cidade> Cidades { get; set; } = new();
    public List<Especie> Especies { get; set; } = new();

    public int? CidadeId { get; set; }
    public int? EspecieId { get; set; }
    public PorteAnimal? Porte { get; set; }
    public string? Busca { get; set; }

    public bool TemFiltro =>
        CidadeId.HasValue || EspecieId.HasValue ||
        Porte.HasValue || !string.IsNullOrWhiteSpace(Busca);
}
