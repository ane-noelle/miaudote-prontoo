namespace Miaudote.Web.ViewModels;

/// <summary>Dados necessários para desenhar os links de paginação.</summary>
public class PaginacaoViewModel
{
    public int PaginaAtual { get; set; } = 1;
    public int TotalPaginas { get; set; } = 1;
    public string Action { get; set; } = "Index";
    public string Controller { get; set; } = string.Empty;

    /// <summary>Filtros atuais, repassados para cada link de página.</summary>
    public Dictionary<string, string?> Parametros { get; set; } = new();

    public bool Visivel => TotalPaginas > 1;
}

public static class Paginador
{
    public const int PaginaInicial = 1;

    public static int Normalizar(int pagina, int total, int tamanho, out int totalPaginas)
    {
        totalPaginas = Math.Max(1, (int)Math.Ceiling(total / (double)tamanho));
        return Math.Clamp(pagina, 1, totalPaginas);
    }
}
