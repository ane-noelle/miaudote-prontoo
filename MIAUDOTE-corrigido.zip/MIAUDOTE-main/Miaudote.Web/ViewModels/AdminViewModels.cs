using Miaudote.Web.Enums;
using Miaudote.Web.Models;

namespace Miaudote.Web.ViewModels;

public class AdminDashboardViewModel
{
    public int AnimaisAtivos { get; set; }
    public int AnimaisDisponiveis { get; set; }
    public int AnimaisEmProcesso { get; set; }
    public int AnimaisAdotados { get; set; }

    public int SolicitacoesPendentes { get; set; }
    public int SolicitacoesEmAnalise { get; set; }
    public int SolicitacoesAprovadas { get; set; }
    public int SolicitacoesRecusadas { get; set; }
    public int SolicitacoesConcluidas { get; set; }

    public int MensagensPendentes { get; set; }

    public List<SolicitacaoAdocao> UltimasSolicitacoes { get; set; } = new();
    public List<MensagemContato> UltimasMensagens { get; set; } = new();
}

public class AdminAnimaisViewModel
{
    public List<Animal> Animais { get; set; } = new();
    public List<Especie> Especies { get; set; } = new();

    public string? Busca { get; set; }
    public StatusAnimal? Status { get; set; }
    public int? EspecieId { get; set; }

    /// <summary>"ativos" (padrão), "inativos" ou "todos".</summary>
    public string Situacao { get; set; } = "ativos";

    public int Total { get; set; }
    public PaginacaoViewModel Paginacao { get; set; } = new();
}

public class AdminSolicitacoesViewModel
{
    public List<SolicitacaoAdocao> Solicitacoes { get; set; } = new();
    public StatusSolicitacao? Status { get; set; }
    public string? Busca { get; set; }

    /// <summary>Quantidade de solicitações por status (para as abas de filtro).</summary>
    public Dictionary<StatusSolicitacao, int> Contagens { get; set; } = new();

    public int Total { get; set; }
    public PaginacaoViewModel Paginacao { get; set; } = new();
}

public class AdminMensagensViewModel
{
    public List<MensagemContato> Mensagens { get; set; } = new();

    /// <summary>"todas" (padrão), "pendentes" ou "respondidas".</summary>
    public string Filtro { get; set; } = "todas";

    public int TotalPendentes { get; set; }
    public int TotalRespondidas { get; set; }
    public PaginacaoViewModel Paginacao { get; set; } = new();
}

public class CadastrosViewModel
{
    public List<ItemCadastro> Especies { get; set; } = new();
    public List<ItemCadastro> Cidades { get; set; } = new();
    public List<ItemCadastro> Temperamentos { get; set; } = new();
}

/// <summary>Linha genérica das tabelas de cadastros auxiliares.</summary>
public class ItemCadastro
{
    public int Id { get; set; }
    public string Nome { get; set; } = string.Empty;
    public string? Uf { get; set; }
    public bool Ativo { get; set; }
    public int EmUso { get; set; }
}
