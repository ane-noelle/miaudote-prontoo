using System.Text.RegularExpressions;
using Miaudote.Web.Data;
using Miaudote.Web.Enums;
using Miaudote.Web.Filters;
using Miaudote.Web.Helpers;
using Miaudote.Web.Models;
using Miaudote.Web.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace Miaudote.Web.Controllers;

[AdminAutorizado]
public class AdministradorController : Controller
{
    private const int TamanhoPaginaAnimais = 12;
    private const int TamanhoPaginaMensagens = 10;
    private const long TamanhoMaximoFoto = 5 * 1024 * 1024;

    // Fotos enviadas pelo painel são salvas com nome GUID. Só esses arquivos
    // podem ser apagados automaticamente (nunca as imagens fixas do site).
    private static readonly Regex NomeFotoEnviada =
        new(@"^[0-9a-f]{32}\.(jpg|png)$", RegexOptions.Compiled);

    private readonly AppDbContext _contexto;
    private readonly IWebHostEnvironment _ambiente;

    public AdministradorController(
        AppDbContext contexto,
        IWebHostEnvironment ambiente)
    {
        _contexto = contexto;
        _ambiente = ambiente;
    }

    // =====================================================================
    //  PAINEL
    // =====================================================================

    public async Task<IActionResult> Index()
    {
        var animaisPorStatus = await _contexto.Animais
            .AsNoTracking()
            .Where(a => a.Ativo)
            .GroupBy(a => a.Status)
            .Select(g => new { Status = g.Key, Total = g.Count() })
            .ToDictionaryAsync(g => g.Status, g => g.Total);

        var solicitacoesPorStatus = await _contexto.SolicitacoesAdocao
            .AsNoTracking()
            .GroupBy(s => s.Status)
            .Select(g => new { Status = g.Key, Total = g.Count() })
            .ToDictionaryAsync(g => g.Status, g => g.Total);

        int Animais(StatusAnimal s) => animaisPorStatus.GetValueOrDefault(s);
        int Solic(StatusSolicitacao s) => solicitacoesPorStatus.GetValueOrDefault(s);

        var modelo = new AdminDashboardViewModel
        {
            AnimaisAtivos = animaisPorStatus.Values.Sum(),
            AnimaisDisponiveis = Animais(StatusAnimal.Disponivel),
            AnimaisEmProcesso = Animais(StatusAnimal.EmProcesso),
            AnimaisAdotados = Animais(StatusAnimal.Adotado),

            SolicitacoesPendentes = Solic(StatusSolicitacao.Pendente),
            SolicitacoesEmAnalise = Solic(StatusSolicitacao.EmAnalise),
            SolicitacoesAprovadas = Solic(StatusSolicitacao.Aprovada),
            SolicitacoesRecusadas = Solic(StatusSolicitacao.Recusada),
            SolicitacoesConcluidas = Solic(StatusSolicitacao.Concluida),

            MensagensPendentes = await _contexto.MensagensContato
                .AsNoTracking()
                .CountAsync(m => !m.Respondida),

            UltimasSolicitacoes = await _contexto.SolicitacoesAdocao
                .AsNoTracking()
                .Include(s => s.Animal)
                .OrderByDescending(s => s.DataSolicitacao)
                .Take(5)
                .ToListAsync(),

            UltimasMensagens = await _contexto.MensagensContato
                .AsNoTracking()
                .OrderBy(m => m.Respondida)
                .ThenByDescending(m => m.DataEnvio)
                .Take(5)
                .ToListAsync()
        };

        return View(modelo);
    }

    // =====================================================================
    //  ANIMAIS
    // =====================================================================

    public async Task<IActionResult> Animais(
        string? busca,
        StatusAnimal? status,
        int? especieId,
        string situacao = "ativos",
        int pagina = 1)
    {
        busca = string.IsNullOrWhiteSpace(busca) ? null : busca.Trim();

        situacao = situacao is "inativos" or "todos" ? situacao : "ativos";

        var consulta = _contexto.Animais
            .AsNoTracking()
            .Include(a => a.Especie)
            .Include(a => a.Cidade)
            .AsQueryable();

        if (situacao == "ativos") consulta = consulta.Where(a => a.Ativo);
        else if (situacao == "inativos") consulta = consulta.Where(a => !a.Ativo);

        if (status.HasValue)
            consulta = consulta.Where(a => a.Status == status.Value);

        if (especieId.HasValue)
            consulta = consulta.Where(a => a.EspecieId == especieId.Value);

        if (busca != null)
        {
            consulta = consulta.Where(a =>
                a.Nome.Contains(busca) ||
                (a.Raca != null && a.Raca.Contains(busca)));
        }

        var total = await consulta.CountAsync();

        pagina = Paginador.Normalizar(pagina, total, TamanhoPaginaAnimais, out var totalPaginas);

        var animais = await consulta
            .OrderByDescending(a => a.DataCadastro)
            .ThenBy(a => a.Nome)
            .Skip((pagina - 1) * TamanhoPaginaAnimais)
            .Take(TamanhoPaginaAnimais)
            .ToListAsync();

        return View(new AdminAnimaisViewModel
        {
            Animais = animais,
            Total = total,
            Busca = busca,
            Status = status,
            EspecieId = especieId,
            Situacao = situacao,
            Especies = await _contexto.Especies
                .AsNoTracking()
                .OrderBy(e => e.Nome)
                .ToListAsync(),
            Paginacao = new PaginacaoViewModel
            {
                PaginaAtual = pagina,
                TotalPaginas = totalPaginas,
                Action = nameof(Animais),
                Controller = "Administrador",
                Parametros = new Dictionary<string, string?>
                {
                    ["busca"] = busca,
                    ["status"] = status.HasValue ? ((int)status.Value).ToString() : null,
                    ["especieId"] = especieId?.ToString(),
                    ["situacao"] = situacao == "ativos" ? null : situacao
                }
            }
        });
    }

    [HttpGet]
    public async Task<IActionResult> NovoAnimal()
    {
        var modelo = new AnimalFormViewModel();
        await PrepararFormularioAsync(modelo);

        return View(modelo);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    [RequestSizeLimit(6 * 1024 * 1024)]
    public async Task<IActionResult> NovoAnimal(
        AnimalFormViewModel modelo,
        IFormFile? foto)
    {
        await ValidarReferenciasAsync(modelo, animalExistente: null);

        if (ModelState.IsValid)
        {
            // A foto só é gravada em disco depois que o resto está válido.
            var resultadoFoto = await SalvarFotoAsync(foto);

            if (resultadoFoto.Erro != null)
            {
                ModelState.AddModelError("foto", resultadoFoto.Erro);
            }
            else
            {
                var animal = new Animal
                {
                    DataCadastro = DateTime.Now,
                    Ativo = true,
                    NomeArquivoImagem = resultadoFoto.NomeArquivo
                };

                AplicarCamposNoAnimal(animal, modelo);
                await SincronizarTemperamentosAsync(animal, modelo.TemperamentoIds);

                _contexto.Animais.Add(animal);
                await _contexto.SaveChangesAsync();

                TempData["Sucesso"] = $"{animal.Nome} foi cadastrado com sucesso.";

                return RedirectToAction(nameof(Animais));
            }
        }

        await PrepararFormularioAsync(modelo);
        return View(modelo);
    }

    [HttpGet]
    public async Task<IActionResult> EditarAnimal(int id)
    {
        var animal = await _contexto.Animais
            .AsNoTracking()
            .Include(a => a.AnimaisTemperamentos)
            .FirstOrDefaultAsync(a => a.Id == id);

        if (animal == null)
        {
            return NotFound();
        }

        var modelo = new AnimalFormViewModel
        {
            Id = animal.Id,
            Nome = animal.Nome,
            EspecieId = animal.EspecieId,
            CidadeId = animal.CidadeId,
            Raca = animal.Raca,
            Anos = animal.IdadeAproximadaMeses / 12,
            Meses = animal.IdadeAproximadaMeses % 12,
            Porte = animal.Porte,
            Genero = animal.Genero,
            Status = animal.Status,
            Descricao = animal.Descricao,
            Vacinado = animal.Vacinado,
            Castrado = animal.Castrado,
            NomeArquivoImagem = animal.NomeArquivoImagem,
            Ativo = animal.Ativo,
            TemperamentoIds = animal.AnimaisTemperamentos
                .Select(at => at.TemperamentoId)
                .ToList()
        };

        await PrepararFormularioAsync(modelo);

        return View(modelo);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    [RequestSizeLimit(6 * 1024 * 1024)]
    public async Task<IActionResult> EditarAnimal(
        int id,
        AnimalFormViewModel modelo,
        IFormFile? foto)
    {
        var animal = await _contexto.Animais
            .Include(a => a.AnimaisTemperamentos)
            .FirstOrDefaultAsync(a => a.Id == id);

        if (animal == null)
        {
            return NotFound();
        }

        modelo.Id = animal.Id;
        modelo.Ativo = animal.Ativo;
        modelo.NomeArquivoImagem = animal.NomeArquivoImagem;

        await ValidarReferenciasAsync(modelo, animal);

        if (ModelState.IsValid)
        {
            var resultadoFoto = await SalvarFotoAsync(foto);

            if (resultadoFoto.Erro != null)
            {
                ModelState.AddModelError("foto", resultadoFoto.Erro);
            }
            else
            {
                var fotoAntiga = animal.NomeArquivoImagem;

                AplicarCamposNoAnimal(animal, modelo);
                animal.DataAtualizacao = DateTime.Now;

                if (resultadoFoto.NomeArquivo != null)
                {
                    animal.NomeArquivoImagem = resultadoFoto.NomeArquivo;
                }

                await SincronizarTemperamentosAsync(animal, modelo.TemperamentoIds);

                await _contexto.SaveChangesAsync();

                if (resultadoFoto.NomeArquivo != null)
                {
                    ApagarFotoEnviada(fotoAntiga);
                }

                TempData["Sucesso"] = $"As alterações de {animal.Nome} foram salvas.";

                return RedirectToAction(nameof(Animais));
            }
        }

        await PrepararFormularioAsync(modelo);
        return View(modelo);
    }

    /// <summary>
    /// Desativa (some do site e da lista padrão) ou reativa um animal.
    /// Não apagamos o registro para preservar o histórico de solicitações.
    /// </summary>
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> AlterarSituacaoAnimal(int id, bool ativar)
    {
        var animal = await _contexto.Animais.FirstOrDefaultAsync(a => a.Id == id);

        if (animal == null)
        {
            return NotFound();
        }

        animal.Ativo = ativar;
        animal.DataAtualizacao = DateTime.Now;

        await _contexto.SaveChangesAsync();

        TempData["Sucesso"] = ativar
            ? $"{animal.Nome} foi reativado e voltou para o site."
            : $"{animal.Nome} foi desativado e não aparece mais no site.";

        return RedirectToAction(nameof(Animais), new { situacao = ativar ? "inativos" : "ativos" });
    }

    // =====================================================================
    //  MENSAGENS DE CONTATO
    // =====================================================================

    public async Task<IActionResult> Mensagens(string filtro = "todas", int pagina = 1)
    {
        filtro = filtro is "pendentes" or "respondidas" ? filtro : "todas";

        var consulta = _contexto.MensagensContato.AsNoTracking().AsQueryable();

        if (filtro == "pendentes") consulta = consulta.Where(m => !m.Respondida);
        else if (filtro == "respondidas") consulta = consulta.Where(m => m.Respondida);

        var total = await consulta.CountAsync();

        pagina = Paginador.Normalizar(pagina, total, TamanhoPaginaMensagens, out var totalPaginas);

        var mensagens = await consulta
            .OrderBy(m => m.Respondida)
            .ThenByDescending(m => m.DataEnvio)
            .Skip((pagina - 1) * TamanhoPaginaMensagens)
            .Take(TamanhoPaginaMensagens)
            .ToListAsync();

        return View(new AdminMensagensViewModel
        {
            Mensagens = mensagens,
            Filtro = filtro,
            TotalPendentes = await _contexto.MensagensContato.CountAsync(m => !m.Respondida),
            TotalRespondidas = await _contexto.MensagensContato.CountAsync(m => m.Respondida),
            Paginacao = new PaginacaoViewModel
            {
                PaginaAtual = pagina,
                TotalPaginas = totalPaginas,
                Action = nameof(Mensagens),
                Controller = "Administrador",
                Parametros = new Dictionary<string, string?>
                {
                    ["filtro"] = filtro == "todas" ? null : filtro
                }
            }
        });
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> MarcarMensagem(int id, bool respondida, string filtro = "todas")
    {
        var mensagem = await _contexto.MensagensContato.FirstOrDefaultAsync(m => m.Id == id);

        if (mensagem == null)
        {
            return NotFound();
        }

        mensagem.Respondida = respondida;
        mensagem.DataResposta = respondida ? DateTime.Now : null;

        await _contexto.SaveChangesAsync();

        TempData["Sucesso"] = respondida
            ? "Mensagem marcada como respondida."
            : "Mensagem marcada como pendente.";

        return RedirectToAction(nameof(Mensagens), new { filtro });
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> ExcluirMensagem(int id, string filtro = "todas")
    {
        var mensagem = await _contexto.MensagensContato.FirstOrDefaultAsync(m => m.Id == id);

        if (mensagem == null)
        {
            return NotFound();
        }

        _contexto.MensagensContato.Remove(mensagem);
        await _contexto.SaveChangesAsync();

        TempData["Sucesso"] = "Mensagem excluída.";

        return RedirectToAction(nameof(Mensagens), new { filtro });
    }

    // =====================================================================
    //  AUXILIARES
    // =====================================================================

    /// <summary>Carrega do banco tudo o que os selects/checkboxes do formulário precisam.</summary>
    private async Task PrepararFormularioAsync(AnimalFormViewModel modelo)
    {
        var especieSelecionada = modelo.EspecieId;
        var cidadeSelecionada = modelo.CidadeId;
        var temperamentosMarcados = modelo.TemperamentoIds;

        // Mostra só itens ativos, mas mantém o item já escolhido (mesmo se
        // foi desativado depois) para a edição não perder o valor.
        modelo.Especies = await _contexto.Especies
            .AsNoTracking()
            .Where(e => e.Ativa || e.Id == especieSelecionada)
            .OrderBy(e => e.Nome)
            .Select(e => new SelectListItem
            {
                Value = e.Id.ToString(),
                Text = e.Ativa ? e.Nome : e.Nome + " (inativa)",
                Selected = e.Id == especieSelecionada
            })
            .ToListAsync();

        modelo.Cidades = await _contexto.Cidades
            .AsNoTracking()
            .Where(c => c.Ativa || c.Id == cidadeSelecionada)
            .OrderBy(c => c.Nome)
            .Select(c => new SelectListItem
            {
                Value = c.Id.ToString(),
                Text = c.Ativa ? c.Nome + " - " + c.Uf : c.Nome + " - " + c.Uf + " (inativa)",
                Selected = c.Id == cidadeSelecionada
            })
            .ToListAsync();

        modelo.TemperamentosDisponiveis = await _contexto.Temperamentos
            .AsNoTracking()
            .Where(t => t.Ativo || temperamentosMarcados.Contains(t.Id))
            .OrderBy(t => t.Nome)
            .ToListAsync();

        modelo.Portes = Opcoes.Portes(modelo.Porte);
        modelo.Generos = Opcoes.Generos(modelo.Genero);
        modelo.StatusOpcoes = Opcoes.StatusAnimais(modelo.Status);
    }

    private async Task ValidarReferenciasAsync(AnimalFormViewModel modelo, Animal? animalExistente)
    {
        if (modelo.EspecieId.HasValue)
        {
            var valida = await _contexto.Especies.AnyAsync(e =>
                e.Id == modelo.EspecieId.Value &&
                (e.Ativa || (animalExistente != null && e.Id == animalExistente.EspecieId)));

            if (!valida)
                ModelState.AddModelError(nameof(modelo.EspecieId), "Selecione uma espécie válida.");
        }

        if (modelo.CidadeId.HasValue)
        {
            var valida = await _contexto.Cidades.AnyAsync(c =>
                c.Id == modelo.CidadeId.Value &&
                (c.Ativa || (animalExistente != null && c.Id == animalExistente.CidadeId)));

            if (!valida)
                ModelState.AddModelError(nameof(modelo.CidadeId), "Selecione uma cidade válida.");
        }

        if (modelo.Porte.HasValue && !Enum.IsDefined(modelo.Porte.Value))
            ModelState.AddModelError(nameof(modelo.Porte), "Selecione um porte válido.");

        if (modelo.Genero.HasValue && !Enum.IsDefined(modelo.Genero.Value))
            ModelState.AddModelError(nameof(modelo.Genero), "Selecione um gênero válido.");

        if (modelo.Status.HasValue && !Enum.IsDefined(modelo.Status.Value))
            ModelState.AddModelError(nameof(modelo.Status), "Selecione um status válido.");

        if (modelo.IdadeTotalMeses > 360)
            ModelState.AddModelError(nameof(modelo.Anos), "A idade máxima é de 30 anos.");
    }

    private static void AplicarCamposNoAnimal(Animal animal, AnimalFormViewModel modelo)
    {
        animal.Nome = modelo.Nome.Trim();
        animal.EspecieId = modelo.EspecieId!.Value;
        animal.CidadeId = modelo.CidadeId!.Value;
        animal.Raca = string.IsNullOrWhiteSpace(modelo.Raca) ? null : modelo.Raca.Trim();
        animal.IdadeAproximadaMeses = modelo.IdadeTotalMeses;
        animal.Porte = modelo.Porte!.Value;
        animal.Genero = modelo.Genero!.Value;
        animal.Status = modelo.Status!.Value;
        animal.Descricao = modelo.Descricao.Trim();
        animal.Vacinado = modelo.Vacinado;
        animal.Castrado = modelo.Castrado;
    }

    /// <summary>Faz a lista de temperamentos do animal ficar igual à lista marcada no formulário.</summary>
    private async Task SincronizarTemperamentosAsync(Animal animal, List<int> idsSelecionados)
    {
        var idsValidos = await _contexto.Temperamentos
            .Where(t => idsSelecionados.Contains(t.Id))
            .Select(t => t.Id)
            .ToListAsync();

        var atuais = animal.AnimaisTemperamentos.ToList();

        foreach (var vinculo in atuais.Where(v => !idsValidos.Contains(v.TemperamentoId)))
        {
            animal.AnimaisTemperamentos.Remove(vinculo);
        }

        var idsAtuais = atuais.Select(v => v.TemperamentoId).ToHashSet();

        foreach (var idNovo in idsValidos.Where(i => !idsAtuais.Contains(i)))
        {
            animal.AnimaisTemperamentos.Add(new AnimalTemperamento
            {
                TemperamentoId = idNovo
            });
        }
    }

    private readonly record struct ResultadoFoto(string? NomeArquivo, string? Erro);

    private async Task<ResultadoFoto> SalvarFotoAsync(IFormFile? foto)
    {
        // Nenhum arquivo escolhido: não é erro (a foto é opcional).
        if (foto == null || foto.Length == 0)
        {
            return new ResultadoFoto(null, null);
        }

        if (foto.Length > TamanhoMaximoFoto)
        {
            return new ResultadoFoto(null, "Selecione uma imagem de até 5 MB.");
        }

        var extensao = Path.GetExtension(foto.FileName).ToLowerInvariant();

        if (extensao is not (".jpg" or ".jpeg" or ".png"))
        {
            return new ResultadoFoto(null, "Envie uma imagem JPG ou PNG.");
        }

        await using var entrada = foto.OpenReadStream();
        using var memoria = new MemoryStream();
        await entrada.CopyToAsync(memoria);

        var dados = memoria.ToArray();

        // Confere os "bytes mágicos" do arquivo: a extensão sozinha não prova nada.
        var ehJpeg = dados.Length >= 3 &&
                     dados[0] == 0xFF && dados[1] == 0xD8 && dados[2] == 0xFF;

        byte[] assinaturaPng = { 0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A };

        var ehPng = dados.Length >= assinaturaPng.Length &&
                    dados.Take(assinaturaPng.Length).SequenceEqual(assinaturaPng);

        var formatoValido =
            (extensao is ".jpg" or ".jpeg" && ehJpeg) ||
            (extensao == ".png" && ehPng);

        if (!formatoValido)
        {
            return new ResultadoFoto(
                null,
                "O conteúdo do arquivo não corresponde a uma imagem JPG ou PNG.");
        }

        var pasta = Path.Combine(
            string.IsNullOrWhiteSpace(_ambiente.WebRootPath)
                ? Path.Combine(_ambiente.ContentRootPath, "wwwroot")
                : _ambiente.WebRootPath,
            "imagens");

        Directory.CreateDirectory(pasta);

        var nomeArquivo = Guid.NewGuid().ToString("N") + (ehPng ? ".png" : ".jpg");

        await System.IO.File.WriteAllBytesAsync(Path.Combine(pasta, nomeArquivo), dados);

        return new ResultadoFoto(nomeArquivo, null);
    }

    private void ApagarFotoEnviada(string? nomeArquivo)
    {
        if (string.IsNullOrWhiteSpace(nomeArquivo) || !NomeFotoEnviada.IsMatch(nomeArquivo))
        {
            return;
        }

        var raiz = string.IsNullOrWhiteSpace(_ambiente.WebRootPath)
            ? Path.Combine(_ambiente.ContentRootPath, "wwwroot")
            : _ambiente.WebRootPath;

        var caminho = Path.Combine(raiz, "imagens", nomeArquivo);

        try
        {
            if (System.IO.File.Exists(caminho))
            {
                System.IO.File.Delete(caminho);
            }
        }
        catch (IOException)
        {
            // Falha ao limpar um arquivo antigo não deve quebrar a edição.
        }
    }
}
