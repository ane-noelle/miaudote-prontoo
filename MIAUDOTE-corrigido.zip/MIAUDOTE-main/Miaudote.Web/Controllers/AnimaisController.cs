using Miaudote.Web.Data;
using Miaudote.Web.Enums;
using Miaudote.Web.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Miaudote.Web.Controllers;

public class AnimaisController : Controller
{
    private const int TamanhoPagina = 9;

    private readonly AppDbContext _contexto;

    public AnimaisController(AppDbContext contexto)
    {
        _contexto = contexto;
    }

    public async Task<IActionResult> Index(
        int? cidadeId,
        int? especieId,
        PorteAnimal? porte,
        string? busca,
        int pagina = 1)
    {
        busca = string.IsNullOrWhiteSpace(busca) ? null : busca.Trim();

        if (busca is { Length: > 100 })
        {
            busca = busca[..100];
        }

        var disponiveis = _contexto.Animais
            .AsNoTracking()
            .Where(animal =>
                animal.Ativo &&
                animal.Status == StatusAnimal.Disponivel);

        var consulta = disponiveis;

        if (cidadeId.HasValue)
            consulta = consulta.Where(a => a.CidadeId == cidadeId.Value);

        if (especieId.HasValue)
            consulta = consulta.Where(a => a.EspecieId == especieId.Value);

        if (porte.HasValue)
            consulta = consulta.Where(a => a.Porte == porte.Value);

        if (busca != null)
        {
            consulta = consulta.Where(a =>
                a.Nome.Contains(busca) ||
                (a.Raca != null && a.Raca.Contains(busca)) ||
                a.Descricao.Contains(busca));
        }

        var total = await consulta.CountAsync();

        pagina = Paginador.Normalizar(
            pagina, total, TamanhoPagina, out var totalPaginas);

        var animais = await consulta
            .Include(a => a.Especie)
            .Include(a => a.Cidade)
            .Include(a => a.AnimaisTemperamentos)
                .ThenInclude(at => at.Temperamento)
            .OrderByDescending(a => a.DataCadastro)
            .ThenBy(a => a.Nome)
            .Skip((pagina - 1) * TamanhoPagina)
            .Take(TamanhoPagina)
            .ToListAsync();

        var parametros = new Dictionary<string, string?>
        {
            ["cidadeId"] = cidadeId?.ToString(),
            ["especieId"] = especieId?.ToString(),
            ["porte"] = porte.HasValue ? ((int)porte.Value).ToString() : null,
            ["busca"] = busca
        };

        var viewModel = new AnimaisIndexViewModel
        {
            Animais = animais,
            Total = total,
            CidadeId = cidadeId,
            EspecieId = especieId,
            Porte = porte,
            Busca = busca,

            Cidades = await _contexto.Cidades
                .AsNoTracking()
                .Where(c => c.Ativa && disponiveis.Any(a => a.CidadeId == c.Id))
                .OrderBy(c => c.Nome)
                .ToListAsync(),

            Especies = await _contexto.Especies
                .AsNoTracking()
                .Where(e => e.Ativa && disponiveis.Any(a => a.EspecieId == e.Id))
                .OrderBy(e => e.Nome)
                .ToListAsync(),

            Paginacao = new PaginacaoViewModel
            {
                PaginaAtual = pagina,
                TotalPaginas = totalPaginas,
                Action = nameof(Index),
                Controller = "Animais",
                Parametros = parametros
            }
        };

        return View(viewModel);
    }

    public async Task<IActionResult> Detalhes(int id)
    {
        var animal = await _contexto.Animais
            .AsNoTracking()
            .Include(a => a.Especie)
            .Include(a => a.Cidade)
            .Include(a => a.AnimaisTemperamentos)
                .ThenInclude(at => at.Temperamento)
            .FirstOrDefaultAsync(a => a.Id == id && a.Ativo);

        if (animal == null)
        {
            return NotFound();
        }

        return View(animal);
    }
}
