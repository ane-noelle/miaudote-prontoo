using System.Diagnostics;
using Miaudote.Web.Data;
using Miaudote.Web.Enums;
using Miaudote.Web.Models;
using Miaudote.Web.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Miaudote.Web.Controllers;

public class HomeController : Controller
{
    private const int QuantidadeDestaques = 6;

    private readonly AppDbContext _contexto;

    public HomeController(AppDbContext contexto)
    {
        _contexto = contexto;
    }

    public async Task<IActionResult> Index()
    {
        var disponiveis = _contexto.Animais
            .AsNoTracking()
            .Where(animal =>
                animal.Ativo &&
                animal.Status == StatusAnimal.Disponivel);

        var destaques = await disponiveis
            .Include(animal => animal.Especie)
            .Include(animal => animal.Cidade)
            .Include(animal => animal.AnimaisTemperamentos)
                .ThenInclude(at => at.Temperamento)
            .OrderByDescending(animal => animal.DataCadastro)
            .ThenBy(animal => animal.Nome)
            .Take(QuantidadeDestaques)
            .ToListAsync();

        var viewModel = new HomeIndexViewModel
        {
            Destaques = destaques,

            QuantidadeAnimaisDisponiveis =
                await disponiveis.CountAsync(),

            QuantidadeAdocoesConcluidas =
                await _contexto.SolicitacoesAdocao
                    .AsNoTracking()
                    .CountAsync(s =>
                        s.Status == StatusSolicitacao.Concluida),

            // Os filtros só oferecem opções que realmente têm animais.
            Cidades = await _contexto.Cidades
                .AsNoTracking()
                .Where(c => c.Ativa && disponiveis.Any(a => a.CidadeId == c.Id))
                .OrderBy(c => c.Nome)
                .ToListAsync(),

            Especies = await _contexto.Especies
                .AsNoTracking()
                .Where(e => e.Ativa && disponiveis.Any(a => a.EspecieId == e.Id))
                .OrderBy(e => e.Nome)
                .ToListAsync()
        };

        return View(viewModel);
    }

    public IActionResult Privacy()
    {
        return View();
    }

    /// <summary>Página amigável para 404 e demais códigos de status.</summary>
    [Route("Home/Status")]
    public IActionResult Status(int codigo = 404)
    {
        Response.StatusCode = codigo;
        return View(codigo);
    }

    [ResponseCache(
        Duration = 0,
        Location = ResponseCacheLocation.None,
        NoStore = true)]
    public IActionResult Error()
    {
        return View(
            new ErrorViewModel
            {
                RequestId =
                    Activity.Current?.Id ??
                    HttpContext.TraceIdentifier
            }
        );
    }
}
