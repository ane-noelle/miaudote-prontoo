using Miaudote.Web.Data;
using Miaudote.Web.Enums;
using Miaudote.Web.Filters;
using Miaudote.Web.Helpers;
using Miaudote.Web.Models;
using Miaudote.Web.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Miaudote.Web.Controllers;

public class AdocaoController : Controller
{
    private const int TamanhoPagina = 12;

    // List<> (e não array) de propósito: no .NET 10, "array.Contains(...)" dentro de
    // consultas do EF Core é resolvido para ReadOnlySpan e falha na tradução.
    private static readonly List<StatusSolicitacao> StatusAbertos = new()
    {
        StatusSolicitacao.Pendente,
        StatusSolicitacao.EmAnalise,
        StatusSolicitacao.Aprovada
    };

    private readonly AppDbContext _contexto;

    public AdocaoController(AppDbContext contexto)
    {
        _contexto = contexto;
    }

    // =====================================================================
    //  ÁREA PÚBLICA: formulário de solicitação
    // =====================================================================

    [HttpGet]
    public async Task<IActionResult> Solicitar(int id)
    {
        var animal = await BuscarAnimalParaSolicitacaoAsync(id);

        if (animal == null)
        {
            return NotFound();
        }

        if (animal.Status != StatusAnimal.Disponivel)
        {
            TempData["Erro"] =
                $"{animal.Nome} não está disponível para novas solicitações no momento.";

            return RedirectToAction("Detalhes", "Animais", new { id });
        }

        return View(new SolicitarAdocaoViewModel
        {
            Animal = animal,
            AnimalId = animal.Id
        });
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Solicitar(int id, SolicitarAdocaoViewModel modelo)
    {
        var animal = await BuscarAnimalParaSolicitacaoAsync(id);

        if (animal == null)
        {
            return NotFound();
        }

        if (animal.Status != StatusAnimal.Disponivel)
        {
            TempData["Erro"] =
                $"{animal.Nome} não está disponível para novas solicitações no momento.";

            return RedirectToAction("Detalhes", "Animais", new { id });
        }

        modelo.Animal = animal;
        modelo.AnimalId = animal.Id;

        modelo.NomeCompleto = modelo.NomeCompleto?.Trim() ?? string.Empty;
        modelo.Email = modelo.Email?.Trim() ?? string.Empty;
        modelo.Telefone = modelo.Telefone?.Trim() ?? string.Empty;
        modelo.Cidade = modelo.Cidade?.Trim() ?? string.Empty;
        modelo.Endereco = modelo.Endereco?.Trim() ?? string.Empty;
        modelo.MotivoAdocao = modelo.MotivoAdocao?.Trim() ?? string.Empty;

        if (ModelState.IsValid)
        {
            var emailMinusculo = modelo.Email.ToLower();

            var jaSolicitou = await _contexto.SolicitacoesAdocao
                .AnyAsync(s =>
                    s.AnimalId == animal.Id &&
                    s.Email.ToLower() == emailMinusculo &&
                    StatusAbertos.Contains(s.Status));

            if (jaSolicitou)
            {
                ModelState.AddModelError(
                    nameof(modelo.Email),
                    "Já existe uma solicitação em andamento para este animal com esse e-mail.");
            }
        }

        if (!ModelState.IsValid)
        {
            return View(modelo);
        }

        _contexto.SolicitacoesAdocao.Add(new SolicitacaoAdocao
        {
            AnimalId = animal.Id,
            NomeCompleto = modelo.NomeCompleto,
            Email = modelo.Email,
            Telefone = modelo.Telefone,
            Cidade = modelo.Cidade,
            Endereco = modelo.Endereco,
            MotivoAdocao = modelo.MotivoAdocao,
            Status = StatusSolicitacao.Pendente,
            DataSolicitacao = DateTime.Now
        });

        await _contexto.SaveChangesAsync();

        TempData["Sucesso"] =
            $"Solicitação para adotar {animal.Nome} enviada com sucesso! " +
            "A equipe responderá no e-mail informado.";

        return RedirectToAction("Detalhes", "Animais", new { id = animal.Id });
    }

    // =====================================================================
    //  ÁREA ADMINISTRATIVA
    // =====================================================================

    [AdminAutorizado]
    [HttpGet]
    public async Task<IActionResult> Solicitacoes(
        StatusSolicitacao? status,
        string? busca,
        int pagina = 1)
    {
        busca = string.IsNullOrWhiteSpace(busca) ? null : busca.Trim();

        var consulta = _contexto.SolicitacoesAdocao
            .AsNoTracking()
            .Include(s => s.Animal)
            .AsQueryable();

        if (status.HasValue)
            consulta = consulta.Where(s => s.Status == status.Value);

        if (busca != null)
        {
            consulta = consulta.Where(s =>
                s.NomeCompleto.Contains(busca) ||
                s.Email.Contains(busca) ||
                (s.Animal != null && s.Animal.Nome.Contains(busca)));
        }

        var total = await consulta.CountAsync();

        pagina = Paginador.Normalizar(pagina, total, TamanhoPagina, out var totalPaginas);

        var lista = await consulta
            .OrderByDescending(s => s.DataSolicitacao)
            .Skip((pagina - 1) * TamanhoPagina)
            .Take(TamanhoPagina)
            .ToListAsync();

        var contagens = await _contexto.SolicitacoesAdocao
            .AsNoTracking()
            .GroupBy(s => s.Status)
            .Select(g => new { Status = g.Key, Total = g.Count() })
            .ToDictionaryAsync(g => g.Status, g => g.Total);

        return View(new AdminSolicitacoesViewModel
        {
            Solicitacoes = lista,
            Status = status,
            Busca = busca,
            Total = total,
            Contagens = contagens,
            Paginacao = new PaginacaoViewModel
            {
                PaginaAtual = pagina,
                TotalPaginas = totalPaginas,
                Action = nameof(Solicitacoes),
                Controller = "Adocao",
                Parametros = new Dictionary<string, string?>
                {
                    ["status"] = status.HasValue ? ((int)status.Value).ToString() : null,
                    ["busca"] = busca
                }
            }
        });
    }

    [AdminAutorizado]
    [HttpGet]
    public async Task<IActionResult> Analisar(int id)
    {
        var solicitacao = await _contexto.SolicitacoesAdocao
            .AsNoTracking()
            .Include(s => s.Animal).ThenInclude(a => a!.Especie)
            .Include(s => s.Animal).ThenInclude(a => a!.Cidade)
            .FirstOrDefaultAsync(s => s.Id == id);

        if (solicitacao == null)
        {
            return NotFound();
        }

        return View(solicitacao);
    }

    [AdminAutorizado]
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> AlterarStatus(
        int id,
        StatusSolicitacao novoStatus,
        string? observacao)
    {
        var solicitacao = await _contexto.SolicitacoesAdocao
            .Include(s => s.Animal)
            .FirstOrDefaultAsync(s => s.Id == id);

        if (solicitacao?.Animal == null)
        {
            return NotFound();
        }

        var animal = solicitacao.Animal;

        if (!FluxoSolicitacao.Permite(solicitacao.Status, novoStatus))
        {
            TempData["Erro"] =
                $"Não é possível mudar de \"{solicitacao.Status.Rotulo()}\" " +
                $"para \"{novoStatus.Rotulo()}\".";

            return RedirectToAction(nameof(Analisar), new { id });
        }

        var emAndamento =
            novoStatus is StatusSolicitacao.Aprovada
                       or StatusSolicitacao.EmAnalise
                       or StatusSolicitacao.Concluida;

        if (emAndamento &&
            animal.Status == StatusAnimal.Adotado &&
            solicitacao.Status != StatusSolicitacao.Aprovada)
        {
            TempData["Erro"] =
                $"{animal.Nome} já foi adotado por meio de outra solicitação.";

            return RedirectToAction(nameof(Analisar), new { id });
        }

        var statusAnterior = solicitacao.Status;

        solicitacao.Status = novoStatus;
        solicitacao.DataAtualizacao = DateTime.Now;
        solicitacao.ObservacaoAdministrativa = LimparObservacao(
            observacao, solicitacao.ObservacaoAdministrativa);

        switch (novoStatus)
        {
            case StatusSolicitacao.Aprovada:
                // Reserva o animal: some da lista pública enquanto a adoção acontece.
                animal.Status = StatusAnimal.EmProcesso;
                animal.DataAtualizacao = DateTime.Now;
                break;

            case StatusSolicitacao.Concluida:
                animal.Status = StatusAnimal.Adotado;
                animal.DataAtualizacao = DateTime.Now;
                await RecusarOutrasSolicitacoesAbertasAsync(solicitacao);
                break;

            case StatusSolicitacao.Recusada:
            case StatusSolicitacao.EmAnalise:
                if (statusAnterior == StatusSolicitacao.Aprovada)
                {
                    await LiberarAnimalSeNaoHouverAprovadaAsync(animal, solicitacao.Id);
                }
                break;
        }

        await _contexto.SaveChangesAsync();

        TempData["Sucesso"] = novoStatus switch
        {
            StatusSolicitacao.Aprovada =>
                $"Solicitação aprovada. {animal.Nome} agora está \"Em processo de adoção\".",
            StatusSolicitacao.Concluida =>
                $"Adoção concluída! {animal.Nome} foi marcado como Adotado.",
            StatusSolicitacao.Recusada => "Solicitação recusada.",
            _ => $"Status atualizado para \"{novoStatus.Rotulo()}\"."
        };

        return RedirectToAction(nameof(Analisar), new { id });
    }

    [AdminAutorizado]
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> SalvarObservacao(int id, string? observacao)
    {
        var solicitacao = await _contexto.SolicitacoesAdocao
            .FirstOrDefaultAsync(s => s.Id == id);

        if (solicitacao == null)
        {
            return NotFound();
        }

        solicitacao.ObservacaoAdministrativa = LimparObservacao(observacao, null);
        solicitacao.DataAtualizacao = DateTime.Now;

        await _contexto.SaveChangesAsync();

        TempData["Sucesso"] = "Observação salva.";

        return RedirectToAction(nameof(Analisar), new { id });
    }

    // ---------------------------------------------------------------------

    private Task<Animal?> BuscarAnimalParaSolicitacaoAsync(int id) =>
        _contexto.Animais
            .AsNoTracking()
            .Include(a => a.Especie)
            .Include(a => a.Cidade)
            .FirstOrDefaultAsync(a => a.Id == id && a.Ativo);

    private static string? LimparObservacao(string? texto, string? valorAtual)
    {
        if (texto == null)
        {
            return valorAtual;
        }

        texto = texto.Trim();

        if (texto.Length == 0)
        {
            return null;
        }

        return texto.Length > 3000 ? texto[..3000] : texto;
    }

    private async Task RecusarOutrasSolicitacoesAbertasAsync(SolicitacaoAdocao concluida)
    {
        var outras = await _contexto.SolicitacoesAdocao
            .Where(s =>
                s.AnimalId == concluida.AnimalId &&
                s.Id != concluida.Id &&
                StatusAbertos.Contains(s.Status))
            .ToListAsync();

        foreach (var outra in outras)
        {
            outra.Status = StatusSolicitacao.Recusada;
            outra.DataAtualizacao = DateTime.Now;
            outra.ObservacaoAdministrativa = string.IsNullOrWhiteSpace(outra.ObservacaoAdministrativa)
                ? "Recusada automaticamente: o animal foi adotado em outra solicitação."
                : outra.ObservacaoAdministrativa;
        }
    }

    private async Task LiberarAnimalSeNaoHouverAprovadaAsync(Animal animal, int solicitacaoAtualId)
    {
        if (animal.Status != StatusAnimal.EmProcesso)
        {
            return;
        }

        var existeOutraAprovada = await _contexto.SolicitacoesAdocao
            .AnyAsync(s =>
                s.AnimalId == animal.Id &&
                s.Id != solicitacaoAtualId &&
                s.Status == StatusSolicitacao.Aprovada);

        if (!existeOutraAprovada)
        {
            animal.Status = StatusAnimal.Disponivel;
            animal.DataAtualizacao = DateTime.Now;
        }
    }
}
