using Miaudote.Web.Data;
using Miaudote.Web.Models;
using Microsoft.AspNetCore.Mvc;

namespace Miaudote.Web.Controllers;

public class ContatoController : Controller
{
    private readonly AppDbContext _contexto;

    public ContatoController(AppDbContext contexto)
    {
        _contexto = contexto;
    }

    [HttpGet]
    public IActionResult Index()
    {
        return View(new MensagemContato());
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Index(
        [Bind("Nome,Email,Assunto,Mensagem")] MensagemContato modelo)
    {
        // Os campos ficam "aparados" para não gravar espaços sobrando.
        modelo.Nome = modelo.Nome?.Trim() ?? string.Empty;
        modelo.Email = modelo.Email?.Trim() ?? string.Empty;
        modelo.Assunto = modelo.Assunto?.Trim() ?? string.Empty;
        modelo.Mensagem = modelo.Mensagem?.Trim() ?? string.Empty;

        if (!ModelState.IsValid)
        {
            // Devolve o formulário com o que a pessoa já tinha digitado.
            return View(modelo);
        }

        modelo.Id = 0;
        modelo.Respondida = false;
        modelo.DataResposta = null;
        modelo.DataEnvio = DateTime.Now;

        _contexto.MensagensContato.Add(modelo);
        await _contexto.SaveChangesAsync();

        TempData["Sucesso"] =
            "Mensagem enviada com sucesso! Responderemos em breve.";

        return RedirectToAction(nameof(Index));
    }
}
