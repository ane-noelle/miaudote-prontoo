using Miaudote.Web.Data;
using Miaudote.Web.Filters;
using Miaudote.Web.Models;
using Miaudote.Web.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Miaudote.Web.Controllers;

/// <summary>
/// Gerencia as listas usadas pelos formulários: espécies, cidades e
/// temperamentos. Antes elas eram fixas no HTML do formulário de animais.
/// </summary>
[AdminAutorizado]
public class CadastrosController : Controller
{
    private const string Especie = "especie";
    private const string Cidade = "cidade";
    private const string Temperamento = "temperamento";

    private readonly AppDbContext _contexto;

    public CadastrosController(AppDbContext contexto)
    {
        _contexto = contexto;
    }

    [HttpGet]
    public async Task<IActionResult> Index()
    {
        var modelo = new CadastrosViewModel
        {
            Especies = await _contexto.Especies
                .AsNoTracking()
                .OrderBy(e => e.Nome)
                .Select(e => new ItemCadastro
                {
                    Id = e.Id,
                    Nome = e.Nome,
                    Ativo = e.Ativa,
                    EmUso = _contexto.Animais.Count(a => a.EspecieId == e.Id)
                })
                .ToListAsync(),

            Cidades = await _contexto.Cidades
                .AsNoTracking()
                .OrderBy(c => c.Nome)
                .Select(c => new ItemCadastro
                {
                    Id = c.Id,
                    Nome = c.Nome,
                    Uf = c.Uf,
                    Ativo = c.Ativa,
                    EmUso = _contexto.Animais.Count(a => a.CidadeId == c.Id)
                })
                .ToListAsync(),

            Temperamentos = await _contexto.Temperamentos
                .AsNoTracking()
                .OrderBy(t => t.Nome)
                .Select(t => new ItemCadastro
                {
                    Id = t.Id,
                    Nome = t.Nome,
                    Ativo = t.Ativo,
                    EmUso = _contexto.AnimaisTemperamentos.Count(at => at.TemperamentoId == t.Id)
                })
                .ToListAsync()
        };

        return View(modelo);
    }

    /// <summary>Cria (id = 0) ou renomeia um item.</summary>
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Salvar(string tipo, int id, string? nome, string? uf)
    {
        nome = nome?.Trim();

        switch (tipo)
        {
            case Especie:
                return await SalvarEspecieAsync(id, nome);
            case Cidade:
                return await SalvarCidadeAsync(id, nome, uf?.Trim().ToUpperInvariant());
            case Temperamento:
                return await SalvarTemperamentoAsync(id, nome);
            default:
                return NotFound();
        }
    }

    /// <summary>Ativa ou desativa um item (itens inativos somem dos formulários e filtros).</summary>
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Alternar(string tipo, int id)
    {
        string nome;
        bool ativo;

        switch (tipo)
        {
            case Especie:
                var especie = await _contexto.Especies.FindAsync(id);
                if (especie == null) return NotFound();
                especie.Ativa = !especie.Ativa;
                (nome, ativo) = (especie.Nome, especie.Ativa);
                break;

            case Cidade:
                var cidade = await _contexto.Cidades.FindAsync(id);
                if (cidade == null) return NotFound();
                cidade.Ativa = !cidade.Ativa;
                (nome, ativo) = (cidade.Nome, cidade.Ativa);
                break;

            case Temperamento:
                var temperamento = await _contexto.Temperamentos.FindAsync(id);
                if (temperamento == null) return NotFound();
                temperamento.Ativo = !temperamento.Ativo;
                (nome, ativo) = (temperamento.Nome, temperamento.Ativo);
                break;

            default:
                return NotFound();
        }

        await _contexto.SaveChangesAsync();

        TempData["Sucesso"] = ativo
            ? $"\"{nome}\" foi ativado."
            : $"\"{nome}\" foi desativado.";

        return VoltarPara(tipo);
    }

    /// <summary>Exclui definitivamente — só itens que nenhum animal usa.</summary>
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Excluir(string tipo, int id)
    {
        string nome;

        switch (tipo)
        {
            case Especie:
                var especie = await _contexto.Especies.FindAsync(id);
                if (especie == null) return NotFound();
                if (await _contexto.Animais.AnyAsync(a => a.EspecieId == id))
                    return Recusar(tipo, especie.Nome);
                nome = especie.Nome;
                _contexto.Especies.Remove(especie);
                break;

            case Cidade:
                var cidade = await _contexto.Cidades.FindAsync(id);
                if (cidade == null) return NotFound();
                if (await _contexto.Animais.AnyAsync(a => a.CidadeId == id))
                    return Recusar(tipo, cidade.Nome);
                nome = cidade.Nome;
                _contexto.Cidades.Remove(cidade);
                break;

            case Temperamento:
                var temperamento = await _contexto.Temperamentos.FindAsync(id);
                if (temperamento == null) return NotFound();
                if (await _contexto.AnimaisTemperamentos.AnyAsync(at => at.TemperamentoId == id))
                    return Recusar(tipo, temperamento.Nome);
                nome = temperamento.Nome;
                _contexto.Temperamentos.Remove(temperamento);
                break;

            default:
                return NotFound();
        }

        await _contexto.SaveChangesAsync();

        TempData["Sucesso"] = $"\"{nome}\" foi excluído.";

        return VoltarPara(tipo);
    }

    // ---------------------------------------------------------------------

    private async Task<IActionResult> SalvarEspecieAsync(int id, string? nome)
    {
        if (!NomeValido(nome, 50, "A espécie")) return VoltarPara(Especie);

        var duplicado = await _contexto.Especies
            .AnyAsync(e => e.Id != id && e.Nome == nome);

        if (duplicado) return Erro(Especie, $"Já existe a espécie \"{nome}\".");

        if (id == 0)
        {
            _contexto.Especies.Add(new Especie { Nome = nome!, Ativa = true });
        }
        else
        {
            var especie = await _contexto.Especies.FindAsync(id);
            if (especie == null) return NotFound();
            especie.Nome = nome!;
        }

        await _contexto.SaveChangesAsync();
        return Sucesso(Especie, id == 0 ? $"Espécie \"{nome}\" cadastrada." : "Espécie atualizada.");
    }

    private async Task<IActionResult> SalvarCidadeAsync(int id, string? nome, string? uf)
    {
        if (!NomeValido(nome, 100, "A cidade")) return VoltarPara(Cidade);

        if (uf is not { Length: 2 } || !uf.All(char.IsLetter))
            return Erro(Cidade, "Informe a UF com exatamente 2 letras (ex.: SP).");

        var duplicada = await _contexto.Cidades
            .AnyAsync(c => c.Id != id && c.Nome == nome && c.Uf == uf);

        if (duplicada) return Erro(Cidade, $"Já existe a cidade \"{nome} - {uf}\".");

        if (id == 0)
        {
            _contexto.Cidades.Add(new Cidade { Nome = nome!, Uf = uf, Ativa = true });
        }
        else
        {
            var cidade = await _contexto.Cidades.FindAsync(id);
            if (cidade == null) return NotFound();
            cidade.Nome = nome!;
            cidade.Uf = uf;
        }

        await _contexto.SaveChangesAsync();
        return Sucesso(Cidade, id == 0 ? $"Cidade \"{nome} - {uf}\" cadastrada." : "Cidade atualizada.");
    }

    private async Task<IActionResult> SalvarTemperamentoAsync(int id, string? nome)
    {
        if (!NomeValido(nome, 60, "O temperamento")) return VoltarPara(Temperamento);

        var duplicado = await _contexto.Temperamentos
            .AnyAsync(t => t.Id != id && t.Nome == nome);

        if (duplicado) return Erro(Temperamento, $"Já existe o temperamento \"{nome}\".");

        if (id == 0)
        {
            _contexto.Temperamentos.Add(new Temperamento { Nome = nome!, Ativo = true });
        }
        else
        {
            var temperamento = await _contexto.Temperamentos.FindAsync(id);
            if (temperamento == null) return NotFound();
            temperamento.Nome = nome!;
        }

        await _contexto.SaveChangesAsync();
        return Sucesso(Temperamento, id == 0 ? $"Temperamento \"{nome}\" cadastrado." : "Temperamento atualizado.");
    }

    private bool NomeValido(string? nome, int maximo, string artigoENome)
    {
        if (string.IsNullOrWhiteSpace(nome))
        {
            TempData["Erro"] = $"{artigoENome} precisa de um nome.";
            return false;
        }

        if (nome.Length > maximo)
        {
            TempData["Erro"] = $"{artigoENome} deve ter no máximo {maximo} caracteres.";
            return false;
        }

        return true;
    }

    private IActionResult Erro(string tipo, string mensagem)
    {
        TempData["Erro"] = mensagem;
        return VoltarPara(tipo);
    }

    private IActionResult Sucesso(string tipo, string mensagem)
    {
        TempData["Sucesso"] = mensagem;
        return VoltarPara(tipo);
    }

    private IActionResult Recusar(string tipo, string nome)
    {
        TempData["Erro"] =
            $"\"{nome}\" está em uso por animais e não pode ser excluído. " +
            "Desative-o para que deixe de aparecer nos formulários.";

        return VoltarPara(tipo);
    }

    /// <summary>Volta para a página de cadastros já rolando até a seção certa.</summary>
    private IActionResult VoltarPara(string tipo) =>
        Redirect(Url.Action(nameof(Index))! + "#" + tipo);
}
