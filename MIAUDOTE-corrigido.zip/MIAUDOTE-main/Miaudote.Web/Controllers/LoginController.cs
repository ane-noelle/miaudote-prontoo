using System.Security.Cryptography;
using System.Text;
using Miaudote.Web.Filters;
using Miaudote.Web.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace Miaudote.Web.Controllers;

public class LoginController : Controller
{
    private readonly IConfiguration _configuracao;
    private readonly ILogger<LoginController> _logger;

    public LoginController(
        IConfiguration configuracao,
        ILogger<LoginController> logger)
    {
        _configuracao = configuracao;
        _logger = logger;
    }

    [HttpGet]
    public IActionResult Index(string? returnUrl = null)
    {
        if (HttpContext.Session.GetString(AdminAutorizadoAttribute.ChaveSessao) == "true")
        {
            return RedirectToAction("Index", "Administrador");
        }

        return View(new LoginViewModel { ReturnUrl = returnUrl });
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Index(LoginViewModel modelo)
    {
        if (!ModelState.IsValid)
        {
            modelo.Senha = string.Empty;
            return View(modelo);
        }

        // Credenciais vêm da configuração (appsettings / variáveis de ambiente
        // / user-secrets) e não mais escritas direto no código.
        var emailEsperado = _configuracao["Administrador:Email"] ?? string.Empty;
        var senhaEsperada = _configuracao["Administrador:Senha"] ?? string.Empty;

        var credenciaisOk =
            emailEsperado.Length > 0 &&
            senhaEsperada.Length > 0 &&
            IguaisEmTempoConstante(modelo.Email.Trim().ToLowerInvariant(),
                                   emailEsperado.Trim().ToLowerInvariant()) &
            IguaisEmTempoConstante(modelo.Senha, senhaEsperada);

        if (!credenciaisOk)
        {
            _logger.LogWarning(
                "Tentativa de login administrativo inválida. IP: {Ip}",
                HttpContext.Connection.RemoteIpAddress);

            // Pequeno atraso dificulta tentativas automáticas de adivinhar a senha.
            await Task.Delay(600);

            modelo.Senha = string.Empty;
            ModelState.AddModelError(string.Empty, "E-mail ou senha inválidos.");
            return View(modelo);
        }

        // Nova sessão a cada login (evita reaproveitar uma sessão antiga).
        HttpContext.Session.Clear();
        HttpContext.Session.SetString(AdminAutorizadoAttribute.ChaveSessao, "true");

        if (!string.IsNullOrWhiteSpace(modelo.ReturnUrl) &&
            Url.IsLocalUrl(modelo.ReturnUrl))
        {
            return LocalRedirect(modelo.ReturnUrl);
        }

        return RedirectToAction("Index", "Administrador");
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Logout()
    {
        HttpContext.Session.Clear();

        TempData["Sucesso"] = "Você saiu da área administrativa.";

        return RedirectToAction("Index", "Home");
    }

    private static bool IguaisEmTempoConstante(string a, string b)
    {
        var hashA = SHA256.HashData(Encoding.UTF8.GetBytes(a));
        var hashB = SHA256.HashData(Encoding.UTF8.GetBytes(b));

        return CryptographicOperations.FixedTimeEquals(hashA, hashB);
    }
}
