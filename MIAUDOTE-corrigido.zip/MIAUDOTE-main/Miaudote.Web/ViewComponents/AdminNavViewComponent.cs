using Miaudote.Web.Data;
using Miaudote.Web.Enums;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Miaudote.Web.ViewComponents;

/// <summary>Menu da área administrativa, com contadores de itens que pedem atenção.</summary>
public class AdminNavViewComponent : ViewComponent
{
    private readonly AppDbContext _contexto;

    public AdminNavViewComponent(AppDbContext contexto)
    {
        _contexto = contexto;
    }

    public async Task<IViewComponentResult> InvokeAsync()
    {
        var modelo = new AdminNavViewModel
        {
            SolicitacoesPendentes = await _contexto.SolicitacoesAdocao
                .AsNoTracking()
                .CountAsync(s => s.Status == StatusSolicitacao.Pendente),

            MensagensPendentes = await _contexto.MensagensContato
                .AsNoTracking()
                .CountAsync(m => !m.Respondida)
        };

        return View(modelo);
    }
}

public class AdminNavViewModel
{
    public int SolicitacoesPendentes { get; set; }
    public int MensagensPendentes { get; set; }
}
