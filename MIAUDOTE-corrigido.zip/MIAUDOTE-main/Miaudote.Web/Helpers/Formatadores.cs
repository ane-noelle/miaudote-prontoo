using Miaudote.Web.Enums;

namespace Miaudote.Web.Helpers;

/// <summary>
/// Converte valores técnicos (enums, meses) em textos amigáveis em português.
/// Usado por todas as views para manter a apresentação consistente.
/// </summary>
public static class Formatadores
{
    public static string Idade(int meses)
    {
        if (meses < 0) meses = 0;

        var anos = meses / 12;
        var resto = meses % 12;

        string Anos(int n) => $"{n} {(n == 1 ? "ano" : "anos")}";
        string Meses(int n) => $"{n} {(n == 1 ? "mês" : "meses")}";

        if (anos == 0) return Meses(resto);
        if (resto == 0) return Anos(anos);
        return $"{Anos(anos)} e {Meses(resto)}";
    }

    public static string Rotulo(this PorteAnimal porte) => porte switch
    {
        PorteAnimal.Pequeno => "Pequeno",
        PorteAnimal.Medio => "Médio",
        PorteAnimal.Grande => "Grande",
        _ => porte.ToString()
    };

    public static string Rotulo(this GeneroAnimal genero) => genero switch
    {
        GeneroAnimal.Macho => "Macho",
        GeneroAnimal.Femea => "Fêmea",
        _ => genero.ToString()
    };

    public static string Rotulo(this StatusAnimal status) => status switch
    {
        StatusAnimal.Disponivel => "Disponível",
        StatusAnimal.EmProcesso => "Em processo de adoção",
        StatusAnimal.Adotado => "Adotado",
        StatusAnimal.Indisponivel => "Indisponível",
        _ => status.ToString()
    };

    public static string Rotulo(this StatusSolicitacao status) => status switch
    {
        StatusSolicitacao.Pendente => "Pendente",
        StatusSolicitacao.EmAnalise => "Em análise",
        StatusSolicitacao.Aprovada => "Aprovada",
        StatusSolicitacao.Recusada => "Recusada",
        StatusSolicitacao.Concluida => "Concluída",
        _ => status.ToString()
    };

    /// <summary>Sufixo de classe CSS para o selo (badge) de status.</summary>
    public static string Classe(this StatusAnimal status) => status switch
    {
        StatusAnimal.Disponivel => "ok",
        StatusAnimal.EmProcesso => "alerta",
        StatusAnimal.Adotado => "info",
        _ => "neutro"
    };

    public static string Classe(this StatusSolicitacao status) => status switch
    {
        StatusSolicitacao.Pendente => "alerta",
        StatusSolicitacao.EmAnalise => "info",
        StatusSolicitacao.Aprovada => "ok",
        StatusSolicitacao.Recusada => "erro",
        StatusSolicitacao.Concluida => "concluido",
        _ => "neutro"
    };

    public static string Resumo(string? texto, int maximo)
    {
        if (string.IsNullOrWhiteSpace(texto)) return string.Empty;

        texto = texto.Trim();
        return texto.Length <= maximo
            ? texto
            : texto[..maximo].TrimEnd() + "…";
    }

    /// <summary>Texto do local do animal: "Cidade - UF".</summary>
    public static string Local(Models.Cidade? cidade) =>
        cidade == null ? "Cidade não informada" : $"{cidade.Nome} - {cidade.Uf}";

    /// <summary>Caminho público da foto ou null quando não há foto.</summary>
    public static string? CaminhoFoto(string? nomeArquivo) =>
        string.IsNullOrWhiteSpace(nomeArquivo) ? null : "/imagens/" + nomeArquivo;
}
