using Miaudote.Web.Enums;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace Miaudote.Web.Helpers;

/// <summary>Listas de opções (selects) com textos em português.</summary>
public static class Opcoes
{
    public static List<SelectListItem> Portes(PorteAnimal? selecionado = null) =>
        Montar(selecionado, p => p.Rotulo());

    public static List<SelectListItem> Generos(GeneroAnimal? selecionado = null) =>
        Montar(selecionado, g => g.Rotulo());

    public static List<SelectListItem> StatusAnimais(StatusAnimal? selecionado = null) =>
        Montar(selecionado, s => s.Rotulo());

    public static List<SelectListItem> StatusSolicitacoes(StatusSolicitacao? selecionado = null) =>
        Montar(selecionado, s => s.Rotulo());

    private static List<SelectListItem> Montar<T>(T? selecionado, Func<T, string> rotulo)
        where T : struct, Enum
    {
        return Enum.GetValues<T>()
            .Select(valor => new SelectListItem
            {
                Value = Convert.ToInt32(valor).ToString(),
                Text = rotulo(valor),
                Selected = selecionado.HasValue && selecionado.Value.Equals(valor)
            })
            .ToList();
    }
}
