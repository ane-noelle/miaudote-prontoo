using Miaudote.Web.Enums;

namespace Miaudote.Web.Helpers;

/// <summary>
/// Regras de quais mudanças de status são permitidas em uma solicitação.
/// Usado pelo controller (validação) e pela view (quais botões mostrar).
/// </summary>
public static class FluxoSolicitacao
{
    private static readonly Dictionary<StatusSolicitacao, StatusSolicitacao[]> Transicoes = new()
    {
        [StatusSolicitacao.Pendente] =
            new[] { StatusSolicitacao.EmAnalise, StatusSolicitacao.Aprovada, StatusSolicitacao.Recusada },

        [StatusSolicitacao.EmAnalise] =
            new[] { StatusSolicitacao.Aprovada, StatusSolicitacao.Recusada },

        [StatusSolicitacao.Aprovada] =
            new[] { StatusSolicitacao.Concluida, StatusSolicitacao.EmAnalise, StatusSolicitacao.Recusada },

        [StatusSolicitacao.Recusada] =
            new[] { StatusSolicitacao.EmAnalise },

        // Adoção concluída é definitiva.
        [StatusSolicitacao.Concluida] = Array.Empty<StatusSolicitacao>()
    };

    public static IReadOnlyList<StatusSolicitacao> Proximos(StatusSolicitacao atual) =>
        Transicoes.TryGetValue(atual, out var lista) ? lista : Array.Empty<StatusSolicitacao>();

    public static bool Permite(StatusSolicitacao atual, StatusSolicitacao novo) =>
        Proximos(atual).Contains(novo);

    /// <summary>Texto do botão para levar a solicitação a um novo status.</summary>
    public static string Acao(StatusSolicitacao novo) => novo switch
    {
        StatusSolicitacao.EmAnalise => "Colocar em análise",
        StatusSolicitacao.Aprovada => "Aprovar",
        StatusSolicitacao.Recusada => "Recusar",
        StatusSolicitacao.Concluida => "Concluir adoção",
        StatusSolicitacao.Pendente => "Voltar para pendente",
        _ => novo.ToString()
    };

    public static string ClasseBotao(StatusSolicitacao novo) => novo switch
    {
        StatusSolicitacao.Aprovada => "btn-sucesso",
        StatusSolicitacao.Concluida => "btn-roxo",
        StatusSolicitacao.Recusada => "btn-perigo",
        _ => "btn-neutro"
    };

    public static string Confirmacao(StatusSolicitacao novo) => novo switch
    {
        StatusSolicitacao.Recusada => "Recusar esta solicitação?",
        StatusSolicitacao.Concluida =>
            "Concluir a adoção? O animal será marcado como Adotado e as demais solicitações abertas serão recusadas.",
        _ => string.Empty
    };
}
