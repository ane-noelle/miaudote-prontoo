using Miaudote.Web.Filters;

namespace Miaudote.Web.Helpers;

public static class SessaoExtensions
{
    /// <summary>Indica se o visitante atual está autenticado como administrador.</summary>
    public static bool EhAdministrador(this HttpContext contexto) =>
        contexto.Session.GetString(AdminAutorizadoAttribute.ChaveSessao) == "true";
}
