/*
 * MIAUDOTE — scripts do site.
 * Todos os recursos verificam se o elemento existe antes de usá-lo,
 * para que nenhuma página quebre por causa de outra.
 */
(function () {
    "use strict";

    // ---------- Menu responsivo (celular) ----------
    var botaoMenu = document.querySelector(".menu-toggle");
    var menu = document.getElementById("menu-principal");

    if (botaoMenu && menu) {
        botaoMenu.addEventListener("click", function () {
            var aberto = menu.classList.toggle("aberto");
            botaoMenu.setAttribute("aria-expanded", aberto ? "true" : "false");
            botaoMenu.setAttribute("aria-label", aberto ? "Fechar menu" : "Abrir menu");
        });

        // Fecha o menu ao clicar em um link ou ao apertar Esc
        menu.addEventListener("click", function (e) {
            if (e.target.closest("a")) {
                menu.classList.remove("aberto");
                botaoMenu.setAttribute("aria-expanded", "false");
            }
        });

        document.addEventListener("keydown", function (e) {
            if (e.key === "Escape" && menu.classList.contains("aberto")) {
                menu.classList.remove("aberto");
                botaoMenu.setAttribute("aria-expanded", "false");
                botaoMenu.focus();
            }
        });
    }

    // ---------- Avisos (sucesso / erro) ----------
    document.querySelectorAll(".aviso").forEach(function (aviso) {
        var fechar = aviso.querySelector(".aviso__fechar");

        function remover() {
            aviso.classList.add("aviso--saindo");
            setTimeout(function () { aviso.remove(); }, 250);
        }

        if (fechar) fechar.addEventListener("click", remover);

        // Avisos de sucesso somem sozinhos; os de erro ficam até serem fechados.
        if (aviso.classList.contains("aviso-sucesso")) {
            setTimeout(remover, 7000);
        }
    });

    // ---------- Confirmação antes de ações destrutivas ----------
    // Uso: <form data-confirmar="Texto"> ou <button data-confirmar="Texto">
    document.addEventListener("submit", function (e) {
        var form = e.target;
        if (!(form instanceof HTMLFormElement)) return;

        var botao = e.submitter;
        var mensagem =
            (botao && botao.getAttribute("data-confirmar")) ||
            form.getAttribute("data-confirmar");

        if (mensagem && !window.confirm(mensagem)) {
            e.preventDefault();
        }
    });

    // ---------- Prévia da foto escolhida (formulário de animal) ----------
    document.querySelectorAll('input[type="file"][data-previa]').forEach(function (campo) {
        var destino = document.querySelector(campo.getAttribute("data-previa"));
        if (!destino) return;

        campo.addEventListener("change", function () {
            var arquivo = campo.files && campo.files[0];

            if (!arquivo || !arquivo.type.startsWith("image/")) {
                destino.hidden = true;
                destino.removeAttribute("src");
                return;
            }

            if (destino.dataset.url) URL.revokeObjectURL(destino.dataset.url);

            var url = URL.createObjectURL(arquivo);
            destino.dataset.url = url;
            destino.src = url;
            destino.hidden = false;
        });
    });

    // ---------- Evita duplo clique no envio de formulários ----------
    document.addEventListener("submit", function (e) {
        var form = e.target;
        if (!(form instanceof HTMLFormElement) || e.defaultPrevented) return;

        // Se o jQuery Validate bloqueou o envio, o evento já foi cancelado acima.
        var botao = e.submitter;
        if (botao && form.method.toLowerCase() === "post" && !botao.hasAttribute("data-permitir-reenvio")) {
            setTimeout(function () { botao.disabled = true; }, 0);
            // Reativa caso a pessoa volte pelo botão "voltar" do navegador.
            window.addEventListener("pageshow", function () { botao.disabled = false; });
        }
    });
})();
