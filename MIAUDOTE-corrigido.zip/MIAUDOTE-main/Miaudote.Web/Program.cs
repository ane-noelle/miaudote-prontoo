using Miaudote.Web.Data;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

var conexaoBanco = builder.Configuration
    .GetConnectionString("ConexaoPadrao");

if (string.IsNullOrWhiteSpace(conexaoBanco))
{
    throw new InvalidOperationException(
        "A string de conexão 'ConexaoPadrao' não foi configurada."
    );
}

builder.Services.AddDbContext<AppDbContext>(options =>
{
    options.UseMySql(
        conexaoBanco,
        ServerVersion.AutoDetect(conexaoBanco)
    );
});

builder.Services.AddControllersWithViews();

builder.Services.AddSession(opcoes =>
{
    opcoes.IdleTimeout = TimeSpan.FromHours(2);
    opcoes.Cookie.Name = ".Miaudote.Sessao";
    opcoes.Cookie.HttpOnly = true;
    opcoes.Cookie.IsEssential = true;
    opcoes.Cookie.SameSite = SameSiteMode.Lax;
});

var app = builder.Build();

// Cria/atualiza as tabelas automaticamente ao iniciar.
// Desative com "Banco:MigrarAoIniciar": false em produção, se preferir
// aplicar as migrations manualmente (dotnet ef database update).
if (app.Configuration.GetValue("Banco:MigrarAoIniciar", true))
{
    using var escopo = app.Services.CreateScope();

    escopo.ServiceProvider
        .GetRequiredService<AppDbContext>()
        .Database
        .Migrate();
}

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

// Páginas amigáveis para 404 e outros códigos de erro HTTP.
app.UseStatusCodePagesWithReExecute("/Home/Status", "?codigo={0}");

app.UseHttpsRedirection();

app.UseStaticFiles();

app.UseRouting();

app.UseSession();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}"
);

app.Run();
