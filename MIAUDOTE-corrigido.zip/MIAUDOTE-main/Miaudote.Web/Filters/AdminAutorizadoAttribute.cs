using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace Miaudote.Web.Filters;

/// <summary>
/// Restringe uma action (ou um controller inteiro) ao administrador logado.
/// Substitui o método EstaLogado() que era repetido em cada action.
/// Quando não há sessão, redireciona ao login e guarda a página pedida.
/// </summary>
[AttributeUsage(AttributeTargets.Class | AttributeTargets.Method)]
public sealed class AdminAutorizadoAttribute : ActionFilterAttribute
{
    public const string ChaveSessao = "Administrador";

    public override void OnActionExecuting(ActionExecutingContext contexto)
    {
        var http = contexto.HttpContext;

        // Páginas administrativas nunca devem ficar em cache do navegador.
        http.Response.Headers.CacheControl = "no-store";

        if (http.Session.GetString(ChaveSessao) == "true")
        {
            return;
        }

        var destino = http.Request.Method == HttpMethods.Get
            ? http.Request.Path + http.Request.QueryString
            : null;

        contexto.Result = new RedirectToActionResult(
            "Index",
            "Login",
            new { returnUrl = destino });
    }
}
